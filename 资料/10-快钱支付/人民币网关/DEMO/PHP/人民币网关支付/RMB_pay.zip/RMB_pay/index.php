<style type="text/css">
	td{text-align:center}
</style>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title></title>
	</head>
<body>
		<div align="center">
			<h2 align="center">FI</h2>
			
    		<table width="500" border="1" style="border-collapse: collapse" bordercolor="green" align="center">
				<tr>
					<td align="center">
						<a href="FI_All.php"  style="text-decoration:none" target="_blank">人民币网关</a>
					</td>					
				</tr>
				<tr>
					<td align="center">
						<a href="FI_Qrcode.php"  style="text-decoration:none" target="_blank">PC扫码直连</a>
					</td>					
				</tr>
			</table>
		</div>

</body>	
	</html>