﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.IO;
using System.Xml;
using System.Text;
public partial class _Default : System.Web.UI.Page
{
    #region 参数说明

    //商户编号 退款接口版本号 对于新系统注册商户，该值为商户在快钱的会员编号；对于老系统注册商户，该值为商户在快钱的商户编号。
    public string merchant_id;
    //老版本：bill_drawback_api_1 新版本：bill_drawback_api_2 委托退款：bill_drawback_api_3
    public string version;
    //操作类型 固定值：001 001 代表下订单请求退款
    public string command_type;
    //退款流水号  字符串
    public string txOrder;
    //退款金额  整数或小数，小数位为两位 以人民币  元 为单位。
    public string amount;
    //退款提交时间 格式为：年[4 位]月[2 位]日[2 位]时[2 位]分[2 位]秒[2位]  例如：20071117020101
    public string postdate;
    //原商户订单号  与用户支付时的订单号相同
    public string orderid;
    //原交易收款账户 如果version为bill_drawback_api_3，则此字段不能为空。表示原交易的收款账户（快钱用户的email地址）
    public string payeeidsrc;
    //加密字符串  用于进行安全校验
    //merchant_id={merchant_id}version={version}command_type={command_type}
    //orderid={orderid}amount={amount}postdate={postdate}txOrder={txOrder}
    //merchant_key={merchant_key}payeeidsrc={payeeidsrc}
    public string mac;
    //退款密钥 功能开通后快钱发送到商户快钱帐号邮箱
    public string merchant_key;

    public string macVal = "";
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        this.Panel1.Visible = true;

        merchant_id = "10012140356";
        version = "bill_drawback_api_1";
        command_type = "001";
        txOrder = DateTime.Now.ToString("yyyyMMddHHmmss");
        amount = "1";
        postdate = DateTime.Now.ToString("yyyyMMddHHmmss");
        orderid = "20130114111328";
        payeeidsrc = "";
        merchant_key = "H77G94MDSJC7R76H";


        macVal = appendParam(macVal, "merchant_id", merchant_id);
        macVal = appendParam(macVal, "version", version);
        macVal = appendParam(macVal, "command_type", command_type);
        macVal = appendParam(macVal, "orderid", orderid);
        macVal = appendParam(macVal, "amount", amount);
        macVal = appendParam(macVal, "postdate", postdate);
        macVal = appendParam(macVal, "txOrder", txOrder);
        macVal = appendParam(macVal, "merchant_key", merchant_key);
        macVal = appendParam(macVal, "payeeidsrc", payeeidsrc);

        mac = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(macVal, "MD5").ToUpper();

    }


    /// <summary>
    /// 获取url返回
    /// </summary>
    /// <param name="strURL">请求地址</param>
    /// <param name="timeOut">超时</param>
    /// <returns>返回数据</returns>
    public static string HttpGet(string strURL, int timeOut)
    {
        StringBuilder rStr = new StringBuilder();
        HttpWebRequest request = null;
        HttpWebResponse response = null;
        StreamReader streamReader = null;
        try
        {
            request = (HttpWebRequest)HttpWebRequest.Create(strURL);
            request.Timeout = timeOut;
            response = (HttpWebResponse)request.GetResponse();
            streamReader = new StreamReader(response.GetResponseStream(), Encoding.Default); ;
            rStr.Append(streamReader.ReadToEnd());
            streamReader.Close();
        }
        catch (Exception e)
        {


            StreamWriter sw = File.AppendText(HttpContext.Current.Request.PhysicalApplicationPath + "\\error.txt");
            sw.WriteLine("错误信息:" + e.Message);
            sw.Flush();
            sw.Close();

        }
        finally
        {
            if (streamReader != null)
            {
                streamReader.Close();
            }
            if (response != null)
            {
                response.Close();
            }
            if (request != null)
            {
                request.Abort();
            }
        }
        return rStr.ToString();
    }



    #region 字符串串联函数
    public string appendParam(string returnStr, string paramId, string paramValue)
    {
        if (returnStr != "")
        {
            if (paramValue != "")
            {
                returnStr += paramId + "=" + paramValue;
            }
        }
        else
        {
            if (paramValue != "")
            {
                returnStr = paramId + "=" + paramValue;
            }
        }
        return returnStr;
    }
    #endregion



    protected void Button1_Click(object sender, EventArgs e)
    {
        #region 返回解析


        this.Panel1.Visible = false;
        string macV = "merchant_id=" + merchant_id + "&version=" + version + "&command_type=" + command_type + "&txOrder=" + txOrder + "&amount=" + amount + "&postdate=" + postdate + "&orderid=" + orderid + "&payeeidsrc=" + payeeidsrc;
        //提交地址
        string urlstr = "https://sandbox.99bill.com/webapp/receiveDrawbackAction.do?" + macV.Trim() + "&mac=" + mac;
        //记录提交日志
        StreamWriter sw = File.AppendText(HttpContext.Current.Request.PhysicalApplicationPath + "\\log.txt");
        sw.WriteLine("请求url:");
        sw.WriteLine("urlstr:" + urlstr);
        
        
        try
        {


            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(HttpGet(urlstr, 5000));
            //记录返回的xml
            sw.WriteLine("返回的xml:" + xmlDoc.InnerXml);
            sw.Flush();
            sw.Close();


            string MERCHANT = xmlDoc.SelectSingleNode("//MERCHANT").InnerText.ToString();

            string ORDERID = xmlDoc.SelectSingleNode("//ORDERID").InnerText.ToString();

            string TXORDER = xmlDoc.SelectSingleNode("//TXORDER").InnerText.ToString();

            string AMOUNT = xmlDoc.SelectSingleNode("//AMOUNT").InnerText.ToString();
            //Y 为成功
            string RESULT = xmlDoc.SelectSingleNode("//RESULT").InnerText.ToString();
            //错误信息
            string CODE = xmlDoc.SelectSingleNode("//CODE").InnerText.ToString();




            if (RESULT == "Y")
            {
                Response.Write("退款结果：" + RESULT + "退款成功");
            }
            else
            {
                Response.Write("退款失败：" + CODE);
            }

        }
        catch (Exception r)
        {

            Response.Write("返回错误" + r.Message);
        }
       
        #endregion
    }
}
